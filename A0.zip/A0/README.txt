Monday, Feb 2 11:59 p.m.
Assignment 0
By: Ethan Bohling

Functions done:
delete/remove //challenging part was figuring out a way to traverse to the deleted node
isBalanced    //challenging part was figuring out how to determine if any node/s were more than 1 total height of the rest of the tree
worstCaseBST  //challenging part was figuring out how to separately traverse for left and right child worst case trees
Added exception handling to search and remove functions

How to compile/run program
To compile: type make in terminal
To run: type ./aout