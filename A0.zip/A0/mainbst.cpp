#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

#include "bst.h"


//command line argument: name of command file
// see assignment for command file guidelines

int main(int argc, char *argv[])
{
    string line;
    bstree t;

    ifstream Command("output.txt");

    while (getline(Command, line))
    {
        stringstream ss(line);
        string value, value2;

        ss >> value;
        if (stoi(value) == 0)
        {
            Command.close();
            return 0;
        }
        else if (stoi(value) == 1)
        {
            ss >> value2;
            int x = stoi(value2);
            t.insert(x);
        }
        else if (stoi(value) == -1)
        {
            ss >> value2;
            int y = stoi(value2);
            t.remove(y);
        }
        else if (stoi(value) == 2)
        {
            ss >> value2;
            int v = stoi(value2);
            t.search(v);
            cout << "Search " << v <<": " << t.search(v) << endl;
        }
        else if (stoi(value) == 3)
        {
            t.pre();
        }
        else if (stoi(value) == 4)
        {
            t.in();
        }
        else if (stoi(value) == 5)
        {
            t.post();
        }
        else if (stoi(value) == 7)
        {
            cout << "Numnodes = " << t.numnodes() << endl;
        }
        else if (stoi(value) == 8)
        {
            cout << "Height = " << t.height() << endl;
        }
        else if (stoi(value) == 9)
        {
            cout << "The larger subtree is ";
            t.largerside();
        }
        else if (stoi(value) == -2)
        {
            cout << "Is balanced? " << t.isBalanced() << endl;
        }
        else if (stoi(value) == -3)
        {
            bool result = t.worstCaseBST();
            cout << "Is worst-case BST? " << result << endl;
        }
    }
    return 0;
}