#include "bst.h"
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;




// allocate a new node
//   not part of the class
treenode *makeatreenode( int x )
{
    treenode *box;
    box = new treenode;

    box->dat = x;
    box->lchild = NULL;
    box->rchild = NULL;
    return box;
}


bstree::bstree()
{
    root = NULL;
}

void bstree::pre()
{
    cout << "Preorder: ";
    pre(root);
    cout << endl;
}

void bstree::pre(treenode *t)
{
    if (t == NULL)
    {
        return;
    }
    cout << t->dat << " ";
    pre(t->lchild);
    pre(t->rchild);
}

void bstree::in()
{
    cout << "Inorder: ";
    in(root);
    cout << endl;
}

void bstree::in(treenode *t)
{
    if (t == NULL)
    {
        return;
    }
    in(t->lchild);
    cout << t->dat << " ";
    in(t->rchild);

}

void bstree::post()
{
    cout << "Postorder: ";
    post(root);
    cout << endl;
}

void bstree::post(treenode *t)
{
    if (t == NULL)
    {
        return;
    }
    post(t->lchild);
    post(t->rchild);
    cout << t->dat << " ";
}

void bstree::insertI(int val, treenode *t)
{
    bool inserted = false;

    if (t == NULL)
    {
        root = makeatreenode(val);
        return;
    }
    else if (val == t->dat)
    {
        return;
    }

    treenode *tmp = t;
    while (inserted != true)
    {
        if (tmp->lchild == NULL && tmp->rchild == NULL)
        {
            if (val > tmp->dat)
            {
                tmp->rchild = makeatreenode(val);
                inserted = true;
            }
            else
            {
                tmp->lchild = makeatreenode(val);
                inserted = true;
            }
        }
        if (tmp->lchild != NULL && tmp->rchild != NULL)
        {
            if (val > tmp->dat)
            {
                tmp = tmp->rchild;
            }
            else
            {
                tmp = tmp->lchild;
            }
        }
        else if (tmp->lchild != NULL && tmp->rchild == NULL)
        {
            if (val < tmp->dat)
            {
                tmp = tmp->lchild;
            }
            else
            {
                tmp->rchild = makeatreenode(val);
                inserted = true;
            }
        }
        else if (tmp->lchild == NULL && tmp->rchild != NULL)
        {
            if (val < tmp->dat)
            {
                tmp->lchild = makeatreenode(val);
                inserted = true;
            }
            else
            {
                tmp = tmp->rchild;
            }

        }
    }
}

void bstree::insertR(int val, treenode* t) {
    if(t->dat == val) return;
    if(val > t->dat) {
        if(t->rchild == NULL) t->rchild = makeatreenode(val);
        else insertR(val, t->rchild);
    }
    if(val < t->dat) {
        if(t->lchild == NULL) t->lchild = makeatreenode(val);
        else insertR(val, t->lchild);
    }
}
void bstree::insert(int val)
{
    /*
    if(root == NULL){
        root = makeatreenode(val);
    }
    */
    insertI(val, root);
}

void bstree::removeI(int val)
{
    treenode *parent = NULL;
    treenode *curr = root;

    // Find the node to be deleted
    while (curr != NULL && curr->dat != val)
    {
        parent = curr;
        if (val < curr->dat)
        {
            curr = curr->lchild;
        }
        else
        {
            curr = curr->rchild;
        }
    }

    // If the node was not found
    if (curr == NULL)
    {
        return;
    }

    // Case 1: Node has no children (leaf node)
    if (curr->lchild == NULL && curr->rchild == NULL)
    {
        if (curr == root)
        {
            root = NULL;
        }
        else if (parent->lchild == curr)
        {
            parent->lchild = NULL;
        }
        else
        {
            parent->rchild = NULL;
        }
        delete curr;
    }
    // Case 2: Node has one child
    else if (curr->lchild == NULL || curr->rchild == NULL)
    {
        treenode *child;
        if (curr->lchild != NULL)
        {
            child = curr->lchild;
        }
        else {
            child = curr->rchild;
        }
        if (curr == root)
        {
            root = child;
        }
        else if (parent->lchild == curr)
        {
            parent->lchild = child;
        }
        else
        {
            parent->rchild = child;
        }
        delete curr;
    }
    // Case 3: Node has two children
    else
    {
        // Find the maximum value in the left subtree
        treenode *maxNode = curr->lchild;
        treenode *maxParent = curr;
        while (maxNode->rchild != NULL)
        {
            maxParent = maxNode;
            maxNode = maxNode->rchild;
        }

        // Replace the value of the current node with the maximum value
        curr->dat = maxNode->dat;

        // Remove the maximum node from the left subtree
        if (maxParent->lchild == maxNode)
        {
            maxParent->lchild = maxNode->lchild;
        }
        else
        {
            maxParent->rchild = maxNode->lchild;
        }
        delete maxNode;
    }
}

void bstree::remove(int val)
{
    removeI(val);
}


bool bstree::search(int val)
{
    bool res;
    res = search(val, root);
    return res;
}

bool bstree::search(int x, treenode *t)
{
    if (t == NULL)
    {
        return false;
    }
    if (x == t->dat)
    {
        return true;
    }
    if (x < t->dat)
    {
        return search(x, t->lchild);
    }
    else
    {
        return search(x, t->rchild);
    }

}

int bstree::numnodes()
{
    return numnodes(root);
}

int bstree::numnodes(treenode *t)
{
    if (t == NULL)
    {
        return 0;
    }

    int lcount, rcount;
    lcount = numnodes(t->lchild);
    rcount = numnodes(t->rchild);
    return 1 + lcount + rcount;
}


int bstree::height()
{
    return height(root);
}


int bstree::height(treenode *t)
{
    if (t == NULL)
    {
        return 0;
    }

    int left_height = height(t->lchild);
    int right_height = height(t->rchild);
    int height = 1 + max(left_height, right_height);
    return height;
}


void bstree::largerside()
{
    largerside(root);
}

void bstree::largerside(treenode *t)
{
    if (t == NULL)
    {
        return;
    }
    else if (t->lchild == NULL && t->rchild == NULL)
    {
        cout << "neither." << endl;
    }
    else
    {
        int lcount = numnodes(t->lchild);
        int rcount = numnodes(t->rchild);
        if (lcount > rcount)
        {
            cout << "the left subtree." << endl;
        }
        else if (lcount < rcount)
        {
            cout << "the right subtree." << endl;
        }
        else
        {
            cout << "none. The left and right subtree are equal." << endl;
        }
    }
}

int getMax(treenode *t)
{
    if (t == NULL)
    {
        return 0;
    }

    while (t->rchild != NULL)
    {
        t = t->rchild;
    }

    return t->dat;
}


bool bstree::isBalanced()
{
    // A tree is balanced if the heights of the two child subtrees of any node differ by no more than one.
    return isBalanced(root);
}

bool bstree::isBalanced(treenode *t)
{
    if (t == NULL)
    {
        return true;
    }

    int left_height = height(t->lchild);
    int right_height = height(t->rchild);

    if (abs(left_height - right_height) > 1)
    {
        return false; 
    }

    return isBalanced(t->lchild) && isBalanced(t->rchild);
}

bool bstree::worstCaseBST()
{
    return worstCaseBST(root);
}

bool bstree::worstCaseBST(treenode *t)
{       
    treenode *curr = root;

    if (curr->lchild != NULL && curr->rchild == NULL)
    {
        while (curr->lchild != NULL)
        {
            curr = curr->lchild;
            if (curr->rchild != NULL)
            {
                return false;
            }
        }

    }
    else if (curr->lchild == NULL && curr->rchild != NULL)
    {
        while (curr->rchild != NULL)
        {
            curr = curr->rchild;
            if (curr->lchild != NULL)
            {
                return false;
            }
        }
    }
    else
    {
        return false;
    }
    return true;
}