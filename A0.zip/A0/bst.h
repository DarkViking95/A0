// Base Code - linked binary search tree

#include <iostream>
#include <fstream>
using namespace std;


// tree node for linked BST
struct treenode
{
    int dat;
    treenode *lchild;
    treenode *rchild;
};


// Class for binary search tree
// Private will be treenode * to the root

class bstree
{
 public:
    bstree();
    void in( );  // traverses left subtree, then root node, then right subtree. Then, it prints it. 
    void pre( ); // traverses root node, then left subtree, then right subtree. Then, it prints it.
    void post( ); // traverse left subtree, then right subtree, then root node. Then, it prints it.
    void insert( int x );
    void remove( int x );
    bool search( int x );
    int numnodes(); // must compute, not a variable in class
    int height();   // must compute, not a variable in class
    void largerside();
    int getMax(treenode*);
    bool isBalanced();
    bool worstCaseBST();
 private:
    treenode *root;
    void pre(treenode*);
    void in(treenode*);
    void post(treenode*);
    bool search(int x, treenode*);
    void insertI(int x, treenode*);
    void insertR(int x, treenode*);
    void removeI(int x);
    int numnodes(treenode*);
    int height(treenode*);
    void largerside(treenode*);
    bool isBalanced(treenode*);
    bool worstCaseBST(treenode*);
};

